from django.contrib import admin
from django.urls import path
from.  import views

urlpatterns = [
    path('',views.home,name='home'),
    path('PFSDProject/', views.PFSDProject, name='PFSDProject'),
    path('PFSDLogin/', views.PFSDLogin, name='PFSDLogin'),
    path('PFSDRegister/', views.PFSDRegister, name='PFSDRegister'),
    ]