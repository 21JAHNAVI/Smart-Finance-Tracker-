
from django.shortcuts import render,HttpResponse
def home(request):
    return HttpResponse("This is Asha's First Django application")


def PFSDProject(request):
    return render(request,template_name='PFSDApp/PFSDProject.html')

def PFSDLogin(request):
    return render(request,template_name='PFSDApp/PFSDLogin.html')

def PFSDRegister(request):
    return render(request,template_name='PFSDApp/PFSDRegister.html')
# Create your views here.
